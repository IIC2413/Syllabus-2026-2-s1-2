DROP TABLE IF EXISTS prestamos;
DROP TABLE IF EXISTS libros;
DROP TABLE IF EXISTS usuarios;

CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(50) NOT NULL
);

CREATE TABLE libros (
    id SERIAL PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    autor VARCHAR(100) NOT NULL,
    disponible BOOLEAN DEFAULT TRUE
);

CREATE TABLE prestamos (
    id SERIAL PRIMARY KEY,
    id_usuario INT REFERENCES usuarios(id),
    id_libro INT REFERENCES libros(id),
    fecha DATE DEFAULT CURRENT_DATE
);

INSERT INTO usuarios (nombre, password) VALUES
    ('ana', '1234'),
    ('pedro', 'abcd');

INSERT INTO libros (titulo, autor) VALUES
    ('Don Quijote', 'Cervantes'),
    ('Cien años de soledad', 'García Márquez'),
    ('El Principito', 'Saint-Exupéry');