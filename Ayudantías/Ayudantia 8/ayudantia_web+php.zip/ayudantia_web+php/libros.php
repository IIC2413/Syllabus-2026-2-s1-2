<?php
session_start();

if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.php?error=Debes iniciar sesión primero');
    exit();
}

require_once 'db.php';

$db = conectarBD();

$query = "SELECT * FROM libros_disponibles";
$stmt = $db->prepare($query);
$stmt->execute();

$libros = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Biblioteca — Libros</title>
</head>
<body>
    <h1>Bienvenido, <?= htmlspecialchars($_SESSION['nombre']) ?></h1>
    <a href="logout.php">Cerrar sesión</a>

    <h2>Libros disponibles</h2>

    <?php if (isset($_GET['success'])): ?>
        <p style="color:green"><?= htmlspecialchars($_GET['success']) ?></p>
    <?php endif; ?>

    <?php if (isset($_GET['error'])): ?>
        <p style="color:red"><?= htmlspecialchars($_GET['error']) ?></p>
    <?php endif; ?>

    <?php if (empty($libros)): ?>
        <p>No hay libros disponibles.</p>
    <?php else: ?>
        <?php foreach ($libros as $libro): ?>
            <div style="border:1px solid #ccc; padding:10px; margin-bottom:10px;">
                <strong><?= htmlspecialchars($libro['titulo']) ?></strong>
                — <?= htmlspecialchars($libro['autor']) ?>

                <form action="prestar.php" method="POST">
                    <input type="hidden" name="id_libro" value="<?= $libro['id'] ?>">
                    <button type="submit">Pedir prestado</button>
                </form>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>