DROP FUNCTION IF EXISTS fn_actualizar_disponibilidad;

CREATE OR REPLACE FUNCTION fn_actualizar_disponibilidad()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE libros
    SET disponible = FALSE
    WHERE id = NEW.id_libro;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_actualizar_disponibilidad ON prestamos;

CREATE TRIGGER trg_actualizar_disponibilidad
AFTER INSERT ON prestamos
FOR EACH ROW
EXECUTE FUNCTION fn_actualizar_disponibilidad();