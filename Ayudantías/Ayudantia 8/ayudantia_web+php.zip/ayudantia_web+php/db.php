<?php
function conectarBD() {
    $host = 'localhost'; // stonebraker.ing.uc.cl
    $dbname = 'nombre_database'; // <usuario_uc>.e3
    $usuario = 'mi_usuario'; // <usuario_uc>.e3
    $clave = 'mi_clave'; // n° alumno

    try {
        $db = new PDO("pgsql:host=$host;dbname=$dbname", $usuario, $clave);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $db;
    } catch (PDOException $e) {
        echo "Error de conexión: " . $e->getMessage();
        exit();
    }
}
?>