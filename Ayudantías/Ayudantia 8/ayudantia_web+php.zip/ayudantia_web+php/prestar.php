<?php
session_start();

if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.php?error=Debes iniciar sesión primero');
    exit();
}

require_once 'db.php';

$id_libro = $_POST['id_libro'] ?? '';
$id_usuario = $_SESSION['id_usuario'];

$db = conectarBD();

$query = "SELECT id, titulo, disponible
          FROM libros
          WHERE id = :id_libro";
$stmt = $db->prepare($query);
$stmt->bindParam(':id_libro', $id_libro);
$stmt->execute();

$libro = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$libro) {
    header('Location: libros.php?error=El libro no existe');
    exit();
}

if (!$libro['disponible']) {
    header('Location: libros.php?error=Ese libro ya no está disponible');
    exit();
}

$query = "SELECT id
          FROM prestamos
          WHERE id_usuario = :id_usuario AND id_libro = :id_libro";
$stmt = $db->prepare($query);
$stmt->bindParam(':id_usuario', $id_usuario);
$stmt->bindParam(':id_libro', $id_libro);
$stmt->execute();

$prestamo_existente = $stmt->fetch(PDO::FETCH_ASSOC);

if ($prestamo_existente) {
    header('Location: libros.php?error=Ya tienes ese libro prestado');
    exit();
}

try {
    $db->beginTransaction();
    
    $query = "INSERT INTO prestamos (id_usuario, id_libro)
              VALUES (:id_usuario, :id_libro)";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id_usuario', $id_usuario);
    $stmt->bindParam(':id_libro', $id_libro);
    $stmt->execute();

    $db->commit();

    header('Location: libros.php?success=Préstamo realizado correctamente');
    exit();
} catch (Exception $e) { 
    $db->rollBack();
    header('Location: libros.php?error=Error al realizar préstamo');
    exit();
}
?>