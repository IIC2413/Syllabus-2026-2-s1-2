DROP VIEW  IF EXISTS libros_disponibles;

CREATE VIEW libros_disponibles AS
    SELECT
        l.id,
        l.titulo,
        l.autor
    FROM libros l
    WHERE l.disponible = TRUE;