<?php
session_start();

if (isset($_SESSION['id_usuario'])) {
    header('Location: libros.php');
    exit();
}

require_once 'db.php';

$nombre = $_POST['nombre']   ?? '';
$password = $_POST['password'] ?? '';

$db = conectarBD();

$query = "SELECT id, nombre
          FROM usuarios
          WHERE nombre = :nombre AND password = :password";
$stmt = $db->prepare($query);
$stmt->bindParam(':nombre', $nombre);
$stmt->bindParam(':password', $password);
$stmt->execute();

$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if ($usuario) {
    $_SESSION['id_usuario'] = $usuario['id'];
    $_SESSION['nombre'] = $usuario['nombre'];

    header('Location: libros.php');
    exit();
} else {
    header('Location: index.php?error=Usuario o contraseña incorrectos');
    exit();
}
?>