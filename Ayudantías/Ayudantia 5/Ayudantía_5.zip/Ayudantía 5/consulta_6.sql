--EQUIPOS CON MAS JUGADORES NACIDOS EL MISMO MES: muestra el top 10 de equipos donde mas jugadores esten de cumpleaños el mismo mes.

SELECT c.nombre AS club,
       TO_CHAR(j.nacimiento, 'MM') AS mes_nacimiento,
       COUNT(*) AS cantidad_jugadores
FROM jugadores j
JOIN clubes c
  ON j.club_id = c.club_id
WHERE j.nacimiento IS NOT NULL
GROUP BY c.nombre, mes_nacimiento
ORDER BY cantidad_jugadores DESC;
