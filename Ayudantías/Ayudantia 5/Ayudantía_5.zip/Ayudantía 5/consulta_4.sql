-- Número mensual de incorporaciones de jugadores al sistema,
-- y los 5 clubes y 5 ligas con más incorporaciones.

-- A) Incorporaciones mensuales
SELECT
    TO_CHAR(j.fecha_ingreso, 'YYYY-MM') AS mes,
    COUNT(*)                             AS total_incorporaciones
FROM jugadores j
WHERE j.fecha_ingreso IS NOT NULL
GROUP BY mes
ORDER BY mes;

-- B) Top 5 clubes con más incorporaciones históricas
SELECT
    c.nombre  AS club,
    COUNT(*)  AS total_incorporaciones
FROM jugadores j
JOIN clubes c ON j.club_id = c.club_id
WHERE j.fecha_ingreso IS NOT NULL
GROUP BY c.nombre
ORDER BY total_incorporaciones DESC
LIMIT 5;

-- C) Top 5 ligas con más incorporaciones históricas
SELECT
    l.nombre  AS liga,
    COUNT(*)  AS total_incorporaciones
FROM jugadores j
JOIN ligas l ON j.liga_id = l.liga_id
WHERE j.fecha_ingreso IS NOT NULL
GROUP BY l.nombre
ORDER BY total_incorporaciones DESC
LIMIT 5;
