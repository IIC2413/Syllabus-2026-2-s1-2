-- Borrar tablas si existen para poder reejecutar el script sin errores
DROP TABLE IF EXISTS jugador_posiciones CASCADE;
DROP TABLE IF EXISTS posiciones CASCADE;
DROP TABLE IF EXISTS jugadores CASCADE;
DROP TABLE IF EXISTS clubes CASCADE;
DROP TABLE IF EXISTS ligas CASCADE;
DROP TABLE IF EXISTS nacionalidades CASCADE;

CREATE TABLE ligas (
    liga_id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE nacionalidades (
    nacionalidad_id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE posiciones (
    posicion_id SERIAL PRIMARY KEY,
    nombre VARCHAR(10) UNIQUE NOT NULL
);

CREATE TABLE clubes (
    club_id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) UNIQUE NOT NULL,
    liga_id INT REFERENCES ligas(liga_id)
);

CREATE TABLE jugadores (
    sofifa_id INTEGER PRIMARY KEY,
    nombre TEXT,
    nombre_completo TEXT,
    precio_eur NUMERIC,
    edad INTEGER,
    nacimiento DATE,
    altura INTEGER,
    peso INTEGER,
    club_id INT REFERENCES clubes(club_id),
    liga_id INT REFERENCES ligas(liga_id),
    numero INTEGER,
    fecha_ingreso DATE,
    nacionalidad_id INT REFERENCES nacionalidades(nacionalidad_id),
    pie TEXT
);

CREATE TABLE jugador_posiciones (
    jugador_id INT,
    posicion_id INT,
    PRIMARY KEY (jugador_id, posicion_id),
    FOREIGN KEY (jugador_id) REFERENCES jugadores(sofifa_id),
    FOREIGN KEY (posicion_id) REFERENCES posiciones(posicion_id)
);