-- Top 5 posiciones más frecuentes entre los jugadores

SELECT
    p.nombre       AS posicion,
    COUNT(*)       AS cantidad_jugadores
FROM jugador_posiciones jp
JOIN posiciones p ON jp.posicion_id = p.posicion_id
GROUP BY p.nombre
ORDER BY cantidad_jugadores DESC
LIMIT 5;

-- Top 5 ligas con mayor número de jugadores registrados

SELECT
    l.nombre       AS liga,
    COUNT(*)       AS cantidad_jugadores
FROM jugadores j
JOIN ligas l ON j.liga_id = l.liga_id
GROUP BY l.nombre
ORDER BY cantidad_jugadores DESC
LIMIT 5;
