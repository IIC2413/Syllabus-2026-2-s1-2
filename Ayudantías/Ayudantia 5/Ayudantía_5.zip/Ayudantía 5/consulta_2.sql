-- Top 10 ligas con mayor valor total de mercado de sus jugadores

WITH ranking AS (
    SELECT
        l.nombre                    AS liga,
        SUM(j.precio_eur)           AS valor_total_jugadores
    FROM jugadores j
    JOIN ligas l ON j.liga_id = l.liga_id
    WHERE j.precio_eur IS NOT NULL AND j.precio_eur > 0
    GROUP BY l.nombre
),
top_n AS (
    SELECT valor_total_jugadores
    FROM ranking
    ORDER BY valor_total_jugadores DESC
    LIMIT 10
)
SELECT
    r.liga,
    r.valor_total_jugadores
FROM ranking r
WHERE r.valor_total_jugadores >= (SELECT MIN(valor_total_jugadores) FROM top_n)
ORDER BY r.valor_total_jugadores DESC;
