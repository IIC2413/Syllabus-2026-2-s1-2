-- Top 5 jugadores con mayor número de posiciones distintas
-- En caso de empate se muestran todos los jugadores con igual cantidad.

WITH ranking AS (
    SELECT
        j.sofifa_id,
        j.nombre                         AS jugador,
        COUNT(DISTINCT jp.posicion_id)   AS cantidad_posiciones
    FROM jugadores j
    JOIN jugador_posiciones jp ON j.sofifa_id = jp.jugador_id
    GROUP BY j.sofifa_id, j.nombre
),
top_n AS (
    SELECT cantidad_posiciones
    FROM ranking
    ORDER BY cantidad_posiciones DESC
    LIMIT 5
)
SELECT
    r.jugador,
    r.cantidad_posiciones
FROM ranking r
WHERE r.cantidad_posiciones >= (SELECT MIN(cantidad_posiciones) FROM top_n)
ORDER BY r.cantidad_posiciones DESC, r.jugador;
