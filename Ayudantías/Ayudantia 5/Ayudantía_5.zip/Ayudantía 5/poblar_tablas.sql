-- Se crea una tabla temporal
CREATE TEMP TABLE jugadores_tmp (
    sofifa_id INTEGER,
    nombre TEXT,
    nombre_completo TEXT,
    posiciones TEXT,
    precio_eur NUMERIC,
    edad INTEGER,
    nacimiento DATE,
    altura INTEGER,
    peso INTEGER,
    club TEXT,
    liga TEXT,
    numero INTEGER,
    fecha_ingreso DATE,
    nacionalidad TEXT,
    pie TEXT
);

-- Se cargan los datos desde el csv
\copy jugadores_tmp(sofifa_id, nombre, nombre_completo, posiciones, precio_eur, edad, nacimiento, altura, peso, club, liga, numero, fecha_ingreso, nacionalidad, pie) FROM 'players_22.csv' DELIMITER ';' CSV HEADER;

-- Insertamos los datos validos en una tabla definitiva
DROP TABLE IF EXISTS datos CASCADE;

CREATE TABLE datos (
    sofifa_id INTEGER PRIMARY KEY,
    nombre TEXT,
    nombre_completo TEXT,
    posiciones TEXT,
    precio_eur NUMERIC,
    edad INTEGER,
    nacimiento DATE,
    altura INTEGER,
    peso INTEGER,
    club TEXT,
    liga TEXT,
    numero INTEGER,
    fecha_ingreso DATE,
    nacionalidad TEXT,
    pie TEXT
);

-- Se extraen solo los datos válidos para insertar en la tabla datos
INSERT INTO datos (sofifa_id, nombre, nombre_completo, posiciones, precio_eur, edad, nacimiento, altura, peso, club, liga, numero, fecha_ingreso, nacionalidad, pie )
SELECT sofifa_id, nombre, nombre_completo, posiciones, precio_eur, edad, nacimiento, altura, peso, club, liga, numero, fecha_ingreso, nacionalidad, pie
FROM jugadores_tmp
WHERE sofifa_id IS NOT NULL
  AND nombre_completo IS NOT NULL;

-- Poblar tablas con datos únicos para ligas, clubes y nacionalidades
INSERT INTO ligas (nombre)
SELECT DISTINCT liga
FROM datos
WHERE liga IS NOT NULL;

INSERT INTO clubes (nombre, liga_id)
SELECT DISTINCT d.club, l.liga_id
FROM datos d
JOIN ligas l ON d.liga = l.nombre
WHERE d.club IS NOT NULL;

INSERT INTO nacionalidades (nombre)
SELECT DISTINCT nacionalidad
FROM datos
WHERE nacionalidad IS NOT NULL;

-- Poblar tabla principal de jugadores recuperando las llaves foráneas (IDs) mediante LEFT JOINS
INSERT INTO jugadores (sofifa_id, nombre, nombre_completo, precio_eur, edad, nacimiento, altura, peso, club_id, liga_id, numero, fecha_ingreso, nacionalidad_id, pie)
SELECT d.sofifa_id,
       d.nombre,
       d.nombre_completo,
       d.precio_eur,
       d.edad,
       d.nacimiento,
       d.altura,
       d.peso,
       c.club_id,
       l.liga_id,
       d.numero,
       d.fecha_ingreso,
       n.nacionalidad_id,
       d.pie
FROM datos d
LEFT JOIN clubes c ON d.club = c.nombre
LEFT JOIN ligas l ON d.liga = l.nombre
LEFT JOIN nacionalidades n ON d.nacionalidad = n.nombre;

-- Tablas de posiciones (Manejo de strings y arreglos)
INSERT INTO posiciones (nombre)
SELECT DISTINCT unnest(string_to_array(posiciones, ', ')) AS pos
FROM datos
WHERE posiciones IS NOT NULL;

-- Relación muchos a muchos entre jugadores y posiciones
INSERT INTO jugador_posiciones (jugador_id, posicion_id)
SELECT j.sofifa_id, p.posicion_id
FROM datos d
JOIN jugadores j ON d.sofifa_id = j.sofifa_id
JOIN posiciones p ON p.nombre = ANY(string_to_array(d.posiciones, ', '))
WHERE d.posiciones IS NOT NULL;