-- TOP 25 JUGADORES QUE JUEGAN MAS DE UNA POSICION: muestra en orden descendiente los 25 mejores jugadores (segun precio de mercado) que jueguen mas de una posicion, en caso de empate compara por edad ascendente.

SELECT j.nombre AS nombre_jugador,
       c.nombre AS club,
       l.nombre AS liga,
       j.edad,
       j.precio_eur,
       COUNT(p.posicion_id) AS cantidad_posiciones
FROM jugadores j
JOIN clubes c
  ON j.club_id = c.club_id
JOIN ligas l
  ON c.liga_id = l.liga_id
JOIN jugador_posiciones jp
  ON j.sofifa_id = jp.jugador_id
JOIN posiciones p
  ON jp.posicion_id = p.posicion_id
WHERE precio_eur > 0
GROUP BY j.sofifa_id, j.nombre, c.nombre, l.nombre, j.edad, j.precio_eur
HAVING COUNT(p.posicion_id) > 1
ORDER BY j.precio_eur DESC,
         j.edad ASC
LIMIT 25;
